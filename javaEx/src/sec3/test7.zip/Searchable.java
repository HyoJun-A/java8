package sec3;

public interface Searchable {
	void search(String url);
}